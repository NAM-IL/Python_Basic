from lgtm import core

if __name__ == "__main__":
    core.cli()
